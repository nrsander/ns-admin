import { SBSortableHeaderDirective } from './sortable.directive';

export const directives = [SBSortableHeaderDirective];

export * from './sortable.directive';
